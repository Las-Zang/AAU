

Real <- LSTMRsammenligning$`AKTUEL V�RDI`
DFM <- LSTMRsammenligning$DFM
LSTM <- LSTMRsammenligning$LSTM


TSreal = ts(Real, frequency=4, start=c(2008,1), end=c(2019,4))

TSreal = ts(Real, frequency=4, start=c(2008,1), end=c(2019,4))
TSDFM = ts(DFM, frequency=4, start=c(2008,1), end=c(2019,4))
TSLSTM = ts(LSTM, frequency=4, start=c(2008,1), end=c(2019,4))




plot(TSreal,type = "o",col = "black", xlab = "�rstal", ylab = "BNP V�kst", 
     main = "LSTM vs DFM",)

lines(TSDFM, type = "o", col = "blue")


lines(TSLSTM, type = "o", col = "red")

legend("topleft",
       c("DFM","LSTM","Real","Forecast"),
       fill=c("blue","red","black","seagreen"),  
)


rect(xleft=2019,xright = 2020,ybottom=range(TSreal)[1],ytop=range(TSreal)[2], density=2, col = "seagreen")


-axis(side=1,at=c(1,20,30,50),labels=c("2008","2012","2016","2019"))

test = t


a<-ts(rnorm(150),start=c(2002,7),freq=12);a
