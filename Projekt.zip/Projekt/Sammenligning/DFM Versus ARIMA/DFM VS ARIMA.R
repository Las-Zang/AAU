

Real <- Rsammenligningrigtig$`AKTUEL V�RDI`
DFM <- Rsammenligningrigtig$DFM
ARIMA <- Rsammenligningrigtig$ARIMA


TSreal = ts(Real, frequency=4, start=c(2008,1), end=c(2019,4))

TSreal = ts(Real, frequency=4, start=c(2008,1), end=c(2019,4))
TSDFM = ts(DFM, frequency=4, start=c(2008,1), end=c(2019,4))
TSARIMA = ts(ARIMA, frequency=4, start=c(2008,1), end=c(2019,4))




plot(TSreal,type = "o",col = "black", xlab = "�rstal", ylab = "BNP V�kst", 
     main = "ARIMA vs DFM",)

lines(TSDFM, type = "o", col = "blue")


lines(TSARIMA, type = "o", col = "red")

legend("topleft",
       c("DFM","ARIMA","Real","Forecast"),
       fill=c("blue","red","black","seagreen"),  
)


rect(xleft=2019,xright = 2020,ybottom=range(TSreal)[1],ytop=range(TSreal)[2], density=2, col = "seagreen")


-axis(side=1,at=c(1,20,30,50),labels=c("2008","2012","2016","2019"))

test = t


a<-ts(rnorm(150),start=c(2002,7),freq=12);a
