

#n�vendige pakker loades

library(rugarch)
library(fGarch)
library(timeSeries)
library(urca)
library(zoo)
library(urca)
library(timeSeries)
library(sandwich)
library(strucchange)
library(lmtest)
library(MASS)
library(vars)
library(tseries)
library(aTSA)
library(plotrix)
library(forecast)
library(LSTS)
library(Metrics)


#Test Dataset
DendataTEST = BNPkun$GDP[45:48]
TSDendataTEST = ts(DendataTEST, frequency=4, start=c(2019,1), end=c(2019,4))

#Training Dataset
Dendata = BNPkun$GDP[1:44]


#Tr�nings dataset lavet om til en tidsserie
DEN=ts(Dendata, frequency=4, start=c(2008,1), end=c(2018,4))
plot(DEN)



#Unders�ge om serien er station�r 
adf.test(DEN)
Box.test(DEN, lag = 20, type="Ljung")


#ACT og PACF af tisserie
acf(DEN)
pacf(DEN,lag.max=20)
pacf(DEN,lag.max = 5,plot = FALSE)


#Unders�ge hvilken order af arima som giver den laveste AIC.
auto.arima(DEN,trace=TRUE) 

#Vi kan se at en arima (1,1,0)(0,0,1) giver den laveste AIC og derfor anvendes denne Arima model 
arimaorder()



#One step ahead forecast
#Training Dataset
Denmark2019K1 = BNPkun$GDP[1:44]
Denmark2019K2 = BNPkun$GDP[1:45]
Denmark2019K3 = BNPkun$GDP[1:46]
Denmark2019K4 = BNPkun$GDP[1:47]




```{r}

#Tr�nings dataset lavet om til en tidsserie
TSDenmark2019K1=ts(Dendata, frequency=4, start=c(2008,1), end=c(2018,4))
TSDenmark2019K2=ts(Dendata, frequency=4, start=c(2008,1), end=c(2019,1))
TSDenmark2019K3=ts(Dendata, frequency=4, start=c(2008,1), end=c(2019,2))
TSDenmark2019K4=ts(Dendata, frequency=4, start=c(2008,1), end=c(2019,3))


plot(DEN)

#ARIMA dannes
ForecastK1 <-arima(TSDenmark2019K1,order = c(1,1,0),seasonal = list(order=c(0,0,1)))
ForecastK2 <-arima(TSDenmark2019K2,order = c(1,1,0),seasonal = list(order=c(0,0,1)))
ForecastK3 <-arima(TSDenmark2019K3,order = c(1,1,0),seasonal = list(order=c(0,0,1)))
ForecastK4 <-arima(TSDenmark2019K4,order = c(1,1,0),seasonal = list(order=c(0,0,1)))

#model forecaster one step ahead
predict(ForecastK1,n.ahead=1)
predict(ForecastK2,n.ahead=1)
predict(ForecastK3,n.ahead=1)
predict(ForecastK4,n.ahead=1)
