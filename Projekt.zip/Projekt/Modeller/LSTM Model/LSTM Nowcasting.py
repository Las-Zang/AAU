#Nødvendige pakker køres

import keras
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from math import sqrt 
def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

np.random.seed(7)

#Data hentes fra Github
data = pd.read_csv('https://raw.githubusercontent.com/LasZAAU/AAU/master/LSTM2019.csv?fbclid=IwAR12zVdNcv2X1Ta1cJe2TAhiyhs8I78svv6jX87YXKSIlI-zlbHBDELHkWI', low_memory=False,sep=";")
#----------Data forberedes 

#Tid variablen slettes
data = data.drop("Unnamed: 0", axis = 1)    
dataset = data.values
dataset = dataset.astype('float32')

#Output og input specificeres til modellen. (indput og output datasæt)
dataX = dataset[0:144,1:29]
dataY = dataset[0:144,0:1]

#Skalering: Output- og input datasæt bliver skaleret.
scalerX = MinMaxScaler(feature_range=(0,1))
scalerY = MinMaxScaler(feature_range=(0,1))
dataX = scalerX.fit_transform(dataX)
dataY = scalerY.fit_transform(dataY)
n_steps = 1

#Shaping Tensor
dataX3d = np.reshape(dataX,(dataX.shape[0],n_steps,dataX.shape[1]))

#CALLBACK til trning
CB = [keras.callbacks.EarlyStopping(monitor='val_loss', min_delta=0.0001, mode='min', restore_best_weights=True,patience=20)] 

#----------Modellen opbygges med Keras og køres derefter. 
mean_mat0 = np.zeros((len(dataX),0))

for i in range(0,3):
    model = keras.Sequential()
    model.add(keras.layers.LSTM(100, input_shape=(n_steps,28), kernel_initializer='glorot_uniform' ))
    model.add(keras.layers.Dense(1, activation = 'relu'))                           
    model.compile(loss='mean_squared_error', optimizer='adam')
    history = model.fit(dataX3d, dataY, epochs=100, batch_size=12, validation_split=0.069, callbacks=CB)

    tr_pred_sc = model.predict(dataX3d)
    mean_mat0 = np.c_[mean_mat0,tr_pred_sc]

#Root mean squared for modellen
model_mean = mean_mat0.mean(axis=1)
rmse(model_mean[134:144],dataY[134:144])    

# Skaleret data tranformeres tilbage, så det kan sammenlignes med de sande værdier
data_ikke_scale = scalerY.inverse_transform(model_mean.reshape(-1,1))

#Visuel plot af modellen
plt.figure(100)
#plt.plot(mean_mat0) #Inddrages koden, vises alle kørte modeller samt gennemsnittet. 
plt.plot(data_ikke_scale)
plt.plot(dataset[0:144,0])
plt.axvline(x=(len(dataY)*0.93))
plt.show()

#Plot af Model loss
plt.figure(200)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Test', 'Validation'], loc='upper left')
plt.show()

#Root mean squared error (RMSE) udregnes ud for fire kvartaler i 2019  
y_sand_rmse = [0, 1.2, 0.5, 0.6]
y_pred_rmse = [0.25, 0.22, 0.42, 0.44]
rmse = sqrt (mean_squared_error(y_true, y_pred))
print (rmse)

#Moving average error (MAE) udregnes for fire kvartaler i 2019
y_sand_mae = [0, 1.2, 0.5, 0.6]
y_pred_mae = [0.25, 0.22, 0.42, 0.44]
mae = mean_absolute_error(y_sand_mae, y_pred_mae)
print('MAE: %f' % mae)



